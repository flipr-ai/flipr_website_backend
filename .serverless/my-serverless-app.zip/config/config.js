module.exports = {

  "secret": "supersecreat",
  //'database': 'mongodb+srv://admin:admin@flipr-scyzt.mongodb.net/test?retryWrites=true'
  "PAYTM_PROD_URL":"https://secure.paytm.in",
  "MID":"FGPTNq64340845674739",
  "PAYTM_ENVIORMENT": "PROD",   // PROD FOR PRODUCTION
  "PAYTM_MERCHANT_KEY":"CB5PFWVY5#TirERS",
  "WEBSITE": "DEFAULT",
  "CHANNEL_ID": "WEB",
  "INDUSTRY_TYPE_ID":"Retail",
  "PAYTM_FINAL_URL":"https://securegw.paytm.in/theia/processTransaction",
  "EMAIL_ADDRESS":"kishan@flipr.ai",
  "EMAIL_PASSWORD": "Kishan@123"

};